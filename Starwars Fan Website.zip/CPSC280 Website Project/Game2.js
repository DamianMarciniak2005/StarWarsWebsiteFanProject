window.addEventListener("DOMContentLoaded", domLoaded);

function domLoaded() {
   // TODO: Complete the function
   var btn = document.getElementById("convertButton");
   btn.addEventListener("click", convertButtonClicked);

   var celsInput = document.getElementById("cInput");
   var fahrInput = document.getElementById("fInput");

   celsInput.addEventListener("input", function(){clearTextBox(fahrInput)});
   fahrInput.addEventListener("input", function(){clearTextBox(celsInput)});
}

function convertCtoF(degreesCelsius) {
   // TODO: Complete the function
   return (degreesCelsius * (9/5) + 32);
}

function convertFtoC(degreesFahrenheit) {
   // TODO: Complete the function
   return ((degreesFahrenheit - 32) * (5/9));
}

function clearTextBox(textInput) {
   textInput.value = "";
}

function convertButtonClicked() {
   var celsInput = document.getElementById("cInput");
   var fahrInput = document.getElementById("fInput");
   var weatherImg = document.getElementById("weatherImage");
   var errorMessage = document.getElementById("errorMessage");

   errorMessage.textContent = "";  

   if (celsInput.value.length > 0) {
      var celsius = parseFloat(celsInput.value);
      if (isNaN(celsius)) {
         errorMessage.textContent = `${celsInput.value} is not a number`;
         return;
      }
      fahrInput.value = convertCtoF(celsius);
   } else if (fahrInput.value.length > 0) {
      var fahrenheit = parseFloat(fahrInput.value);
      if (isNaN(fahrenheit)) {
         errorMessage.textContent = `${fahrInput.value} is not a number`;
         return;
      }
      celsInput.value = convertFtoC(fahrenheit);
   } else {
      errorMessage.textContent = "Please enter a value in one of the fields.";
      return;
   }

  
   var F = parseFloat(fahrInput.value);
   var descriptionText = document.getElementById("descriptionText");
   
   
   if (F < 32) {
      weatherImg.src = "images/aurora-1197753_1280.jpg";
	  descriptionText.textContent = "The temperature is colder than Hoth!";
	  return;
   } else if (F > 50) {
      weatherImg.src = "images/miniature-2388811_1280.jpg";
	  descriptionText.textContent = "The temperature is hotter than Tatooine!";
	  return;
   } else {
      weatherImg.src = "images/spaceship-7830253_1280.jpg";
	  descriptionText.textContent = "The temperature is just like Naboo!";
	  return;
   }
}
