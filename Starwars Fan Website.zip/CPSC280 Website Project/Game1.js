
class SuperHuman {
   constructor(name, powerLevel) {
      this.name = name;
      this.powerLevel = powerLevel;
   }
}

class SuperHero extends SuperHuman {
   constructor(name, alias, powerLevel) {
      super(name, powerLevel);
      this.alias = alias;
   }

   battle(SuperVillain) {
      if (this.powerLevel >= SuperVillain.powerLevel) {
         return true;
      } else {
         return false;
      }
   
}
}

class SuperVillain extends SuperHuman {
   constructor(name, alias, powerLevel) {
      super(name, powerLevel);
      this.alias = alias;
   }

   getEvilChuckle() {
      return "Ha ha ha!";
   }
}


if (typeof SuperHero === "function" && typeof SuperVillain === "function") {
   const heroes = {
      "Obi-Wan Kenobi": new SuperHero("Obi-Wan", "Obi-Wan Kenobi", 8),
      "Yoda": new SuperHero("Yoda", "Yoda", 10),
      "Mace Windu": new SuperHero("Mace", "Mace Windu", 8),
      "Luke Skywalker": new SuperHero("Luke", "Luke Skywalker", 4)
   };

   const villains = {
      "Darth Maul": new SuperVillain("Maul", "Darth Maul", 7),
      "General Grievous": new SuperVillain("Grievous", "General Grievous", 5),
      "Darth Vader": new SuperVillain("Anakin Skywalker", "Darth Vader", 6),
      "Emperor Palpatine": new SuperVillain("Sheev Palpatine", "Emperor Palpatine", 9)
   };

   registerHandlers();

   function registerHandlers() {
      // Detect selection of hero and villain
      document.querySelector("#heroSelect").addEventListener("change", selectionChanged);
      document.querySelector("#villainSelect").addEventListener("change", selectionChanged);

      selectionChanged();
   }

   function selectionChanged() {
      const selectedHeroValue = document.querySelector("#heroSelect").value;
      const selectedVillainValue = document.querySelector("#villainSelect").value;

      // Get selected hero and villain
      const selectedHero = heroes[selectedHeroValue];
      const selectedVillain = villains[selectedVillainValue];

      let winner;
      if (selectedHero.battle(selectedVillain)) {
         winner = selectedHero.alias;
      }
      else {
         winner = selectedVillain.alias;
      }

      document.querySelector("#winner").innerHTML = `Winner: ${winner}!`;
   }
}
